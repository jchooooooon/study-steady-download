/* Study Steady 화면 (0.2, 회장님 2026-10-25 "시연판 화면 그대로").
 * 메뉴 4개 고정: Plan 계획 · Words 단어 · Review 오답 · Ask 질문 + 설정.
 * 기록은 이 태블릿 안(localStorage)에만. 안드로이드 기능은 window.Steady(Bridge.java), 안드로이드 → 화면은 window.steadyXxx().
 */
'use strict';

// ---------- 안드로이드 다리 (브라우저에서 열면 흉내만) ----------
const S = window.Steady || {
  info: () => JSON.stringify({version: '브라우저', web: 0, owner: false, lock: false, hasPin: false, sdk: 0}),
  check: () => '브라우저에서 보는 중이에요', log: () => '', note: () => {},
  speak: t => { try { const u = new SpeechSynthesisUtterance(t); u.lang = 'en-US'; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { /* 브라우저 미리보기: 소리가 안 나도 됨 */ } },
  listen: () => { setTimeout(() => window.steadyListening(''), 200); setTimeout(() => window.steadyHeard('I like a glass of water'), 1500); },
  stopListen: () => {}, keepScreen: () => {},
  checkPin: p => p === '0000', setPin: () => true, setLock: () => true, release: () => true,
  openWifi: () => toast('브라우저에선 와이파이 창이 없어요'), net: () => '브라우저',
  brightness: () => -1, setBrightness: () => {}, volume: () => .5, setVolume: () => {},
  checkUpdate: () => setTimeout(() => window.steadyUpdate('브라우저에선 업데이트가 없어요'), 300),
  photo: () => setTimeout(() => window.steadyPhotoFail('브라우저에선 사진기가 없어요'), 200),
  saveImage: () => '', deleteImage: () => {},
  aiApps: () => JSON.stringify([{key: 'chatgpt', name: 'ChatGPT', installed: true}, {key: 'gemini', name: 'Gemini', installed: true}]),
  sendToAi: () => true, clipboard: () => '', openEbs: u => window.open(u || 'https://mid.ebs.co.kr'), openSite: (k, u) => window.open(u || siteBy(k).home), takeEvents: () => '[]',
};
window.onerror = (m, src, line) => { try { S.note(`${m} @${line}`); } catch (e) { /* 기록조차 못 하면 넘어감 */ } };

// ---------- 오래된 화면 엔진 검사 ----------
// flex 칸의 gap 을 모르는 엔진(크롬 84 미만)이면 <html class="nogap"> → app.css 가 같은 간격을 여백으로 넣는다 (회장님 온리원 탭, 2026-10-25)
const ENGINE = (navigator.userAgent.match(/Chrome\/(\d+)/) || [])[1] || '?';
(function () {
  const d = document.createElement('div');
  d.style.cssText = 'display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden';
  d.appendChild(document.createElement('div')); d.appendChild(document.createElement('div'));
  document.body.appendChild(d);
  const ok = d.scrollHeight === 1;
  document.body.removeChild(d);
  if (!ok) document.documentElement.classList.add('nogap');
})();

// ---------- 날짜 ----------
const pad2 = n => String(n).padStart(2, '0');
const dayNum = (d = new Date()) => Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000);
const dayKey = (d = new Date()) => `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}`;
const WD = ['일', '월', '화', '수', '목', '금', '토'];
const todayLabel = () => { const d = new Date(); return `${d.getMonth() + 1}월 ${d.getDate()}일 ${WD[d.getDay()]}요일`; };
const hm = m => `${Math.floor(m / 60)}:${pad2(m % 60)}`;
const rel = d => { const t = dayNum(); if (d <= t) return '오늘'; if (d - t === 1) return '내일'; if (d - t <= 60) return `${d - t}일 뒤`; const x = new Date((d + 0.5) * 86400000); return `${x.getMonth() + 1}월 ${x.getDate()}일`; };
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));

// ---------- 저장 ----------
const KEY = 'steady.v2';
const blank = () => ({todos: {}, studied: {}, exam: {name: '', date: ''}, aca: {}, words: {level: 2, perDay: 10, items: {}, newDay: 0, newCount: 0, learned: 0},
  pat: {}, reviews: [], done: [], asked: [], name: '', streak: {last: 0, count: 0, days: []}, memos: {}});
let D;
try { D = Object.assign(blank(), JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { D = blank(); S.note('기록을 읽지 못해 새로 시작: ' + e.message); }
function save() { try { localStorage.setItem(KEY, JSON.stringify(D)); } catch (e) { S.note('기록을 저장하지 못했어요: ' + e.message); toast('저장 공간이 부족해요'); } }

function todos() {
  const k = dayKey();
  if (!D.todos[k]) { // 오늘 처음 열면 어제까지 못 한 일을 가져온다
    const keys = Object.keys(D.todos).filter(x => x < k).sort();
    const last = keys.length ? D.todos[keys[keys.length - 1]] : [];
    D.todos[k] = last.filter(t => !t.done).map(t => Object.assign({}, t, {min: 0}));
    keys.slice(0, -30).forEach(x => delete D.todos[x]); // 30일 넘은 할 일은 지움
    save();
  }
  return D.todos[k];
}
const studied = () => D.studied[dayKey()] || 0;

// ---------- 화면 상태 ----------
const V = {menu: 'home', sheet: null, timer: null, wordTab: 'card', show: false, queue: null, qi: 0, rec: false, heard: '', heardOk: false,
  reviewOpen: null, adding: null, pat: {id: null, view: 'learn', i: 0, said: '', ok: null, hint: false, sit: '전체'}, addImg: '', addSubj: '수학', ask: {img: '', from: null, said: '', mode: 'hint', ai: '', sent: false, answer: ''}, pending: null, toast: null, reloadLater: false, cal: null, memoEdit: null};
const $ = s => document.querySelector(s);

// ---------- 공통 ----------
function toast(msg, undo) {
  clearTimeout(toast.h);
  V.toast = {msg, undo};
  drawToast();
  toast.h = setTimeout(() => { V.toast = null; drawToast(); }, undo ? 4000 : 2200);
}
function drawToast() {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  if (!V.toast) return;
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span>${esc(V.toast.msg)}</span>${V.toast.undo ? '<button data-act="undo">되돌리기</button>' : ''}`;
  document.body.appendChild(t);
}
window.steadyToast = m => toast(m);

function beep() {
  try {
    const a = new (window.AudioContext || window.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain();
    o.frequency.value = 880; o.connect(g); g.connect(a.destination); g.gain.value = .15; o.start(); o.stop(a.currentTime + .35);
  } catch (e) { S.note('알림 소리를 내지 못함: ' + e.message); }
}

// ================= 홈 (회장님 2026-10-25 "메인 화면: 학생 이름, 긍정적인 한 줄, 동기부여, 심플하게 하나 → 카테고리로") =================
// 날마다 바뀌는 한 줄: 쉬운 영어 격언·속담 + 뜻 (영어 공부도 되게). 저작권 걱정 없는 흔한 속담·옛 격언만.
const LINES = [
  ['Little by little, one travels far.', '조금씩 가도 멀리 간다.'], ['Practice makes perfect.', '연습이 완벽을 만든다.'],
  ['Slow and steady wins the race.', '느려도 꾸준하면 이긴다.'], ['Every expert was once a beginner.', '모든 전문가도 한때는 초보였다.'],
  ['Small steps every day.', '매일 작은 한 걸음.'], ['Mistakes help me learn.', '실수는 나를 배우게 한다.'],
  ["Rome wasn't built in a day.", '로마는 하루아침에 이루어지지 않았다.'], ["Where there's a will, there's a way.", '뜻이 있는 곳에 길이 있다.'],
  ["Today's effort is tomorrow's strength.", '오늘의 노력이 내일의 힘이 된다.'], ['You can do it.', '너는 할 수 있어.'],
  ['Knowledge is power.', '아는 것이 힘이다.'], ['One step at a time.', '한 번에 한 걸음씩.'],
  ['Focus on progress, not perfection.', '완벽보다 나아지는 데 집중해.'], ['Done is better than perfect.', '끝낸 것이 완벽한 것보다 낫다.'],
  ['The best time to start is now.', '시작하기 가장 좋은 때는 지금이야.'], ['Believe in yourself.', '너 자신을 믿어.'],
  ['Hard work pays off.', '노력은 결국 보답한다.'], ['Learning never exhausts the mind.', '배움은 결코 마음을 지치게 하지 않는다.'],
  ['A journey of a thousand miles begins with a single step.', '천 리 길도 한 걸음부터.'], ['Dream big, start small.', '꿈은 크게, 시작은 작게.'],
  ['Your future self will thank you.', '미래의 네가 고마워할 거야.'], ['Consistency is the key.', '꾸준함이 열쇠야.'],
  ["Don't give up.", '포기하지 마.'], ['Great things take time.', '멋진 일에는 시간이 걸린다.'],
  ['Be better than yesterday.', '어제보다 조금 더 나은 오늘.'], ['Every day is a fresh start.', '매일이 새로운 시작이야.'],
  ['Try again. Fail better.', '다시 해 봐. 더 잘 실패해 봐.'], ['Keep going. You are getting better.', '계속해. 점점 나아지고 있어.'],
  ['Ask, and you will learn.', '물어보면 배운다.'], ['Well begun is half done.', '시작이 반이다.'],
];
/** 오늘 공부했다고 표시 (타이머·단어·패턴·오답을 하면). 어제도 했으면 연속 +1. */
function markStudy() {
  const t = dayNum(), st = D.streak || (D.streak = {last: 0, count: 0, days: []});
  if (st.last === t) return;
  st.count = st.last === t - 1 ? st.count + 1 : 1;
  st.last = t;
  st.days = (st.days || []).filter(x => x > t - 30).concat(t);
  save();
}
function streakNow() { const st = D.streak || {}, t = dayNum(); return st.last === t || st.last === t - 1 ? st.count : 0; }
/** 한국어 이름 끝 글자 받침에 맞춰 '아/야' (민준아, 서연아 / 지우야). 한글이 아니면 이름만. */
function callName(n) {
  if (!n) return '';
  const c = n.charCodeAt(n.length - 1);
  if (c < 0xac00 || c > 0xd7a3) return n + ',';
  return n + ((c - 0xac00) % 28 ? '아' : '야') + ',';
}
function greetWord() { const h = new Date().getHours(); return h < 5 ? '늦게까지 고생 많아' : h < 11 ? '좋은 아침이야' : h < 17 ? '오늘도 왔구나' : h < 22 ? '오늘도 수고했어' : '늦게까지 고생 많아'; }
function wordStats() {
  if (!EN) return null;
  const t = dayNum(), W = D.words;
  const due = Object.keys(W.items).filter(w => W.items[w].b < 5 && W.items[w].d <= t).length;
  const fresh = W.newDay === t ? Math.max(0, W.perDay - W.newCount) : W.perDay;
  return {due, fresh};
}
// ================= 달력 (회장님 2026-10-25 "첫 화면에 먼쓰리 캘린더, 메모도 되게, 온전한 캘린더로") =================
// 공휴일: 매년 같은 날 + 해마다 바뀌는 날(설·추석·부처님오신날·대체공휴일·선거일). 해마다 바뀌는 날은 2026~2027만 넣어 둠 — 해가 바뀌기 전에 다음 해를 더할 것.
const HOL_FIX = {'0101': '신정', '0301': '삼일절', '0505': '어린이날', '0606': '현충일', '0815': '광복절', '1003': '개천절', '1009': '한글날', '1225': '성탄절'};
const HOL_YEAR = {
  2026: {'0216': '설날', '0217': '설날', '0218': '설날', '0302': '대체공휴일', '0524': '부처님오신날', '0525': '대체공휴일', '0603': '지방선거',
    '0817': '대체공휴일', '0924': '추석', '0925': '추석', '0926': '추석', '1005': '대체공휴일'},
  2027: {'0205': '설날', '0206': '설날', '0207': '설날', '0208': '대체공휴일', '0513': '부처님오신날', '0816': '대체공휴일',
    '0914': '추석', '0915': '추석', '0916': '추석', '1004': '대체공휴일', '1011': '대체공휴일', '1227': '대체공휴일'},
};
function holiday(k) { const md = k.slice(4); return (HOL_YEAR[+k.slice(0, 4)] || {})[md] || HOL_FIX[md] || ''; }
const keyDate = k => new Date(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8));
const examKey = () => (D.exam.date || '').replace(/-/g, '');
function calView() {
  const now = new Date(), c = V.cal || (V.cal = {y: now.getFullYear(), m: now.getMonth()});
  const start = new Date(c.y, c.m, 1).getDay(), days = new Date(c.y, c.m + 1, 0).getDate(), rows = Math.ceil((start + days) / 7);
  const today = dayKey(), ex = examKey();
  let cells = '';
  for (let i = 0; i < rows * 7; i++) {
    const dt = new Date(c.y, c.m, 1 - start + i), k = dayKey(dt), hol = holiday(k), memos = D.memos[k] || [];
    const evs = [];
    if (k === ex) evs.push(`<span class="ev ex">${esc(D.exam.name || '시험')}</span>`);
    memos.forEach(x => evs.push(`<span class="ev">${esc(x.t)}</span>`));
    if (hol && !memos.length) evs.push(`<span class="ev hol">${hol}</span>`);
    const more = evs.length > 1 ? `<small>+${evs.length - 1}</small>` : '';
    const cls = ['cd', dt.getMonth() !== c.m ? 'out' : '', k === today ? 'now' : '', dt.getDay() === 0 || hol ? 'red' : ''].join(' ');
    cells += `<button class="${cls}" data-day="${k}"><span class="dn"><i>${dt.getDate()}</i>${more}</span>${evs.slice(0, 1).join('')}</button>`;
  }
  const isNow = c.y === now.getFullYear() && c.m === now.getMonth();
  return `<section class="cal">
    <div class="chead"><b>${c.y}년 ${c.m + 1}월</b><span class="cnav"><button class="b1 ghost" data-act="cal-prev" aria-label="지난달">‹</button>${isNow ? '' : '<button class="b1" data-act="cal-today">오늘</button>'}<button class="b1 ghost" data-act="cal-next" aria-label="다음달">›</button></span></div>
    <div class="cwd">${WD.map((w, i) => `<span class="${i === 0 ? 'red' : ''}">${w}</span>`).join('')}</div>
    <div class="cdays r${rows}">${cells}</div></section>`;
}
function openDay(k) { V.memoEdit = null; openSheet('day', {key: k}); }
function memoDel(k, id) {
  const list = D.memos[k] || [], i = list.findIndex(x => x.id === id); if (i < 0) return;
  const [m] = list.splice(i, 1);
  if (!list.length) delete D.memos[k];
  save(); render(); drawSheet();
  undoFn = () => { (D.memos[k] || (D.memos[k] = [])).splice(i, 0, m); save(); render(); if (V.sheet && V.sheet.kind === 'day') drawSheet(); };
  toast(`‘${m.t}’ 지웠어요`, true);
}

function home() {
  const line = LINES[dayNum() % LINES.length];
  const left = todos().filter(x => !x.done).length, ws = wordStats(), rv = dueReviews().length, pt = typeof PAT !== 'undefined' && PAT ? patToday() : null;
  const sk = streakNow(), days = (D.streak && D.streak.days) || [], t = dayNum();
  const week = [6, 5, 4, 3, 2, 1, 0].map(k => `<i class="${days.indexOf(t - k) >= 0 ? 'on' : ''}"></i>`).join('');
  const dd = dday();
  const tile = (k, en, ko, sub, hot) => `<button class="tile" data-menu="${k}"><span class="te">${en}</span><span class="tk">${ko}</span><span class="ts ${hot ? 'hot' : ''}">${sub}</span></button>`;
  return `<main class="home">
    <div class="htop"><span class="brand-s">Study Steady</span><span class="hdate">${todayLabel()}${dd ? ` · ${esc(D.exam.name || '시험')} <b class="warm">${dd}</b>` : ''}</span>
      <button class="b1 ghost" data-menu="settings">설정</button></div>
    <div class="hbody"><div class="hmid">
      <div class="hello">${D.name ? `${esc(callName(D.name))}<br>` : ''}${greetWord()}</div>
      <div class="quote"><span class="qen">“${esc(line[0])}”</span><span class="qko">${esc(line[1])}</span></div>
      <div class="streak"><span class="week">${week}</span><span>${sk ? `<b>${sk}일째</b> 꾸준히 공부 중` : '오늘 공부하면 <b>1일째</b>가 시작돼요'}</span></div>
    </div>${calView()}</div>
    <div class="tiles">
      ${tile('plan', 'Plan', '계획', left ? `남은 할 일 ${left}개` : '오늘 할 일을 적어 봐요', left > 0)}
      ${tile('words', 'Words', '단어 · 패턴', ws ? `복습 ${ws.due} · 새 단어 ${ws.fresh}${pt ? ` · ${esc(pt.pattern)}` : ''}` : '단어장 여는 중', ws && ws.due > 0)}
      ${tile('review', 'Review', '오답', rv ? `오늘 다시 풀 문제 ${rv}개` : '오늘 풀 오답 없음', rv > 0)}
      ${tile('ask', 'Ask', '질문', '모르는 문제만 물어봐요', false)}
    </div>
    <div class="links">${SITES.map(x => `<button class="link" data-site="${x.k}"><b>${x.en}</b><span>${x.ko}</span><i>↗</i></button>`).join('')}</div></main>`;
}

// ================= 공부 사이트 (회장님 2026-10-25 "EBS 열기 버튼 말고 왼쪽 카테고리로 따로, 리틀팍스·족보닷컴도 EBS 처럼") =================
// 앱 안 전용 창(EbsActivity)으로 연다. hosts 는 앱 쪽 EbsActivity.SITES 와 같게.
const SITES = [
  {k: 'ebs', en: 'EBS', ko: '강의·시험지', name: 'EBS', home: 'https://mid.ebs.co.kr/', hosts: ['ebs.co.kr', 'ebsi.co.kr', 'ebse.co.kr']},
  {k: 'littlefox', en: 'Little Fox', ko: '리틀팍스', name: '리틀팍스', home: 'https://www.littlefox.co.kr/ko', hosts: ['littlefox.co.kr', 'littlefox.com', 'littlefox.net']},
  {k: 'zocbo', en: '족보닷컴', ko: '기출', name: '족보닷컴', home: 'https://www.zocbo.com/', hosts: ['zocbo.com', 'eduzone.co.kr']},
];
function siteBy(k) { return SITES.filter(x => x.k === k)[0] || SITES[0]; }
/** 주소가 어느 사이트인지 (계획·오답에 넣은 주소 다시 열기). 모르면 EBS (예전 기록은 다 EBS). */
function siteOf(u) {
  let h = '';
  try { h = new URL(u).hostname.toLowerCase(); } catch (e) { return SITES[0]; } // 주소가 아니면 예전처럼 EBS
  return SITES.filter(x => x.hosts.some(z => h === z || h.slice(-z.length - 1) === '.' + z))[0] || SITES[0];
}
function openSite(k, url) {
  if (typeof S.openSite === 'function') S.openSite(k, url || '');
  else if (k === 'ebs') S.openEbs(url || ''); // 앱이 0.2.5 이하: EBS 만 열 수 있음
  else toast('앱 업데이트가 필요해요. 설정 → 업데이트 확인을 눌러 주세요');
}
const openUrl = u => openSite(siteOf(u).k, u);

// ================= 왼쪽 메뉴 =================
function side() {
  const left = todos().filter(x => !x.done).length;
  const wl = V.queue ? Math.max(0, V.queue.length - V.qi) : '';
  const n = (k, en, ko, c) => `<button class="nav ${V.menu === k ? 'on' : ''}" data-menu="${k}"><b>${en}</b><span>${ko}</span>${c ? `<small>${c}</small>` : ''}</button>`;
  return `<nav class="side"><button class="brand" data-menu="home">Study Steady</button>
    ${n('home', 'Home', '홈', '')}${n('plan', 'Plan', '계획', left)}${n('words', 'Words', '단어', wl)}${n('review', 'Review', '오답', dueReviews().length)}${n('ask', 'Ask', '질문', '')}
    <div class="sides">바로 가기</div>${SITES.map(x => `<button class="nav site" data-site="${x.k}"><b>${x.en}</b><span>${x.ko}</span><small>↗</small></button>`).join('')}
    <button class="foot ${V.menu === 'settings' ? 'on' : ''}" data-menu="settings">설정</button></nav>`;
}

// ================= Plan =================
function dday() {
  if (!D.exam.date) return '';
  const [y, m, d] = D.exam.date.split('-').map(Number);
  const n = dayNum(new Date(y, m - 1, d)) - dayNum();
  return n > 0 ? `D-${n}` : n === 0 ? 'D-DAY' : `D+${-n}`;
}
function plan() {
  const list = todos();
  const rows = list.map(x => swRow(`todo:${x.id}`, `<div class="row ${x.done ? 'done' : ''}">
    <button class="box" data-chk="${x.id}" aria-label="체크"><i></i></button>
    <span class="t">${esc(x.t)}${x.tag ? `<span class="tag">${esc(x.tag)}</span>` : ''}</span>
    ${x.done ? `<span class="tm">${x.min ? x.min + '분' : ''}</span>` : `<button class="start" data-start="${x.id}">시작</button>`}</div>`)).join('');
  const aca = D.aca[new Date().getDay()] || '';
  return `<main class="page"><div class="crumb">Plan / ${todayLabel()}</div>
    <h3 class="title">오늘 할 공부</h3>
    <dl class="props">
      <dt>시험</dt><dd class="edit" data-act="exam">${D.exam.date ? `${esc(D.exam.name || '시험')} <span class="num warm">${dday()}</span>` : '<span class="subc">눌러서 시험 날짜 넣기</span>'}</dd>
      <dt>학원</dt><dd class="edit" data-act="aca">${aca ? esc(aca) : '<span class="subc">오늘 학원 없음 (눌러서 넣기)</span>'}</dd>
      <dt>공부한 시간</dt><dd><span class="num">${hm(studied())}</span></dd></dl><hr>
    <div class="todo scroll grow">${rows || '<div class="empty">아래에 오늘 할 일을 써 보세요. EBS·리틀팍스·족보닷컴은 왼쪽 메뉴에서 열고 [오늘 계획에 넣기]를 누르면 여기 들어와요.</div>'}
      <form class="add" id="addf"><span>+</span><input id="addi" placeholder="할 일 추가 (예: 영어 듣기 20분) 후 Enter" maxlength="60" enterkeyhint="done"></form></div>
    ${V.timer ? timerView() : ''}</main>`;
}
function timerView() {
  const x = todos().find(t => t.id === V.timer.id) || {t: ''};
  return `<div class="timer"><div class="what">${esc(x.t)}</div>
    <div class="clock" id="tbig">00:00</div>
    <div class="goal" id="tgoal">목표 25분 · 끝내면 저절로 체크돼요</div>
    <div class="btns">${x.url ? `<button class="b1 big" data-act="ebs-again">${siteOf(x.url).name} 다시 열기</button>` : ''}
      <button class="b1 big" data-act="pause">${V.timer.paused ? '다시 시작' : '잠깐 멈춤'}</button><button class="b1 big dark" data-act="finish">끝냄</button></div></div>`;
}
function startTimer(t) {
  V.timer = {id: t.id, start: Date.now(), pausedMs: 0, paused: 0, beeped: false};
  S.keepScreen(true);
  render();
  if (t.url) openUrl(t.url);
  clearInterval(startTimer.h);
  startTimer.h = setInterval(tickTimer, 500);
}
function timerSec() { const T = V.timer; return Math.max(0, Math.floor(((T.paused || Date.now()) - T.start - T.pausedMs) / 1000)); }
function tickTimer() {
  if (!V.timer) return;
  const s = timerSec(), b = $('#tbig');
  if (b) b.textContent = `${pad2(Math.floor(s / 60))}:${pad2(s % 60)}`;
  if (!V.timer.beeped && s >= 25 * 60) {
    V.timer.beeped = true; beep();
    const g = $('#tgoal'); if (g) { g.textContent = '25분 다 했어요! 더 해도 되고, 끝내도 돼요'; g.classList.add('ok'); }
  }
}
function finishTimer() {
  if (!V.timer) return;
  markStudy();
  const min = Math.max(1, Math.round(timerSec() / 60));
  const t = todos().find(x => x.id === V.timer.id);
  if (t) { t.done = true; t.min = (t.min || 0) + min; }
  D.studied[dayKey()] = studied() + min;
  save();
  clearInterval(startTimer.h);
  V.timer = null; S.keepScreen(false);
  toast(`${min}분 공부했어요`);
  if (V.reloadLater) location.reload(); else render();
}
function addTodo(t, tag, url) { todos().push({id: Date.now(), t: t.slice(0, 60), tag: tag || '', done: false, min: 0, url: url || ''}); save(); }

// ---------- 시트 (작은 창) ----------
function openSheet(kind, data) { V.sheet = {kind, data: data || {}}; drawSheet(); }
function closeSheet() { V.sheet = null; drawSheet(); }
function drawSheet() {
  const L = $('#layer');
  if (!V.sheet) { L.innerHTML = ''; return; }
  const k = V.sheet.kind, d = V.sheet.data;
  let html = '';
  if (k === 'exam') html = `<form class="card" data-form="exam"><h4>시험</h4>
      <label>시험 이름<input name="name" value="${esc(D.exam.name)}" placeholder="예: 2학기 기말"></label>
      <label>시험 날짜<input name="date" type="date" value="${esc(D.exam.date)}"></label>
      <div class="btns"><button type="button" class="b1" data-act="close">취소</button>${D.exam.date ? '<button type="button" class="b1 ghost" data-act="exam-clear">지우기</button>' : ''}<button class="b1 dark">저장</button></div></form>`;
  else if (k === 'aca') html = `<form class="card" data-form="aca"><h4>${WD[d.day]}요일 학원</h4>
      <label>시간과 과목<input name="v" value="${esc(D.aca[d.day] || '')}" placeholder="예: 17:00 수학 · 19:30 영어"></label>
      <div class="btns"><button type="button" class="b1" data-act="close">취소</button><button class="b1 dark">저장</button></div></form>`;
  else if (k === 'score') html = `<form class="card" data-form="score"><h4>점수 적기</h4><p>${esc(d.title || '시험지')}</p>
      <label>맞은 개수 / 전체<input name="sc" inputmode="numeric" placeholder="예: 16/20"></label>
      <label>틀린 번호 (쉼표나 띄어쓰기로)<input name="wr" inputmode="numeric" placeholder="예: 4, 9, 13"></label>
      <p>틀린 번호는 Review 오답에 들어가서 내일 다시 풀게 돼요.</p>
      <div class="btns"><button type="button" class="b1" data-act="close">나중에</button><button class="b1 dark">저장</button></div></form>`;
  else if (k === 'back-from-ebs') html = `<div class="card"><h4>${esc(d.site || 'EBS')} 다 했어요?</h4><p>${esc(d.title)}</p>
      <div class="btns"><button class="b1" data-act="close">계속 공부</button><button class="b1" data-act="score-from-timer">점수 적기</button><button class="b1 dark" data-act="finish-sheet">끝냄</button></div></div>`;
  else if (k === 'pin') html = `<form class="card" data-form="pin"><h4>${esc(d.title)}</h4>${d.msg ? `<p>${esc(d.msg)}</p>` : ''}
      ${d.mode === 'set' && d.hasOld ? '<label>지금 비밀번호<input name="old" type="password" inputmode="numeric" autocomplete="off"></label>' : ''}
      <label>${d.mode === 'set' ? '새 비밀번호 (숫자 4자리 이상)' : '보호자 비밀번호'}<input name="p" type="password" inputmode="numeric" autocomplete="off" autofocus></label>
      <div class="btns">${d.must ? '' : '<button type="button" class="b1" data-act="close">취소</button>'}<button class="b1 dark">확인</button></div></form>`;
  else if (k === 'name') html = `<form class="card" data-form="name"><h4>이름을 알려 줄래요?</h4><p>첫 화면에서 이름을 불러 줄게요. 설정에서 언제든 바꿀 수 있어요.</p>
      <label>이름 (예: 민준)<input name="v" value="${esc(D.name || '')}" maxlength="10" autofocus></label>
      <div class="btns"><button type="button" class="b1 ghost" data-act="name-skip">나중에</button><button class="b1 dark">저장</button></div></form>`;
  else if (k === 'day') {
    const key = d.key, dt = keyDate(key), list = D.memos[key] || [], info = [], hol = holiday(key);
    if (key === examKey()) info.push(`<b class="warm">${esc(D.exam.name || '시험')}</b>`);
    if (hol) info.push(`<span class="warm">${hol}</span>`);
    if (D.aca[dt.getDay()]) info.push(`학원 ${esc(D.aca[dt.getDay()])}`);
    if (D.studied[key]) info.push(`공부한 시간 ${hm(D.studied[key])}`);
    const td = D.todos[key];
    if (td && td.length) info.push(`할 일 ${td.filter(x => x.done).length}/${td.length}`);
    const ed = list.filter(x => x.id === V.memoEdit)[0];
    html = `<form class="card" data-form="memo"><h4>${dt.getMonth() + 1}월 ${dt.getDate()}일 ${WD[dt.getDay()]}요일</h4>${info.length ? `<p>${info.join(' · ')}</p>` : ''}
      <div class="memos">${list.map(x => swRow(`memo:${x.id}`, `<button type="button" class="memo ${x.id === V.memoEdit ? 'on' : ''}" data-mid="${x.id}">${esc(x.t)}</button>`)).join('') || '<div class="empty">아직 메모가 없어요</div>'}</div>
      ${list.length ? '<p class="hint">누르면 고치고, 왼쪽으로 밀면 지워요</p>' : ''}
      <label>${ed ? '메모 고치기' : '메모 쓰기'}<input name="v" maxlength="80" value="${ed ? esc(ed.t) : ''}" placeholder="예: 영어 수행평가 · 준비물 챙기기" enterkeyhint="done"></label>
      <div class="btns">${ed ? '<button type="button" class="b1" data-act="memo-cancel">고치기 취소</button>' : '<button type="button" class="b1" data-act="close">닫기</button>'}<button class="b1 dark">${ed ? '고친 것 저장' : '메모 넣기'}</button></div></form>`;
  }
  else if (k === 'confirm') html = `<div class="card"><h4>${esc(d.title)}</h4><p>${esc(d.msg)}</p>
      <div class="btns"><button class="b1" data-act="close">취소</button><button class="b1 dark" data-act="confirm-yes">${esc(d.yes)}</button></div></div>`;
  else if (k === 'pick') {
    const it = D.reviews.map(r => `<button class="item" data-pick="${r.id}">${thumb(r)}<span>${esc(r.src)}<small>${esc(r.s)}</small></span><span></span></button>`).join('');
    html = `<div class="card"><h4>어떤 문제를 물어볼까요?</h4><div class="list">${it || '<div class="empty">오답에 넣은 문제가 없어요</div>'}</div>
      <div class="btns"><button class="b1" data-act="close">닫기</button></div></div>`;
  } else if (k === 'about') html = `<div class="card"><h4>자료 출처</h4><div class="mono">${esc(d.text)}</div><div class="btns"><button class="b1" data-act="close">닫기</button></div></div>`;
  L.innerHTML = `<div class="sheet">${html}</div>`;
  const f = L.querySelector('[autofocus]'); if (f) setTimeout(() => f.focus(), 50);
}
function askPin(title, msg, ok) { V.pending = ok; openSheet('pin', {title, msg, mode: 'check'}); }
function confirmBox(title, msg, yes, ok) { V.pending = ok; openSheet('confirm', {title, msg, yes}); }

// ================= Words =================
let EN = null;
function loadData() {
  fetch('data/en.tsv').then(r => r.text()).then(t => {
    EN = t.split('\n').map(l => l.split('\t')).filter(a => a.length >= 5 && a[0]).map(a => ({w: a[0], pr: a[1], pos: a[2], ko: a[3], lv: +a[4]}));
    V.queue = null; render();
  }).catch(e => S.note('단어장을 읽지 못함: ' + e.message));
  fetch('data/patterns.json').then(r => r.json()).then(j => { PAT = j; render(); }).catch(e => S.note('패턴을 읽지 못함: ' + e.message));
}
const GAP = [0, 1, 3, 7, 14, 999];
const BOXN = ['오늘', '1일', '3일', '7일', '14일', '외움'];
function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function deck() { return EN ? EN.filter(x => x.lv === D.words.level).sort((a, b) => hash(a.w) - hash(b.w)) : []; }
function buildQueue() {
  const W = D.words, t = dayNum();
  if (W.newDay !== t) { W.newDay = t; W.newCount = 0; save(); }
  const byW = {}; (EN || []).forEach(x => { byW[x.w] = x; });
  const due = Object.keys(W.items).filter(w => W.items[w].b < 5 && W.items[w].d <= t && byW[w]).sort((a, b) => W.items[a].d - W.items[b].d).map(w => ({e: byW[w], isNew: false}));
  const fresh = deck().filter(x => !W.items[x.w]).slice(0, Math.max(0, W.perDay - W.newCount)).map(e => ({e, isNew: true}));
  V.queue = due.concat(fresh); V.qi = 0; V.show = false;
}
function words() {
  if (!EN) return `<main class="page"><div class="crumb">Words</div><div class="wcard"><div class="pr">단어장을 여는 중…</div></div></main>`;
  if (!V.queue) buildQueue();
  const seg = `<div class="seg"><button data-wt="card" class="${V.wordTab === 'card' ? 'on' : ''}">단어 암기</button><button data-wt="pat" class="${V.wordTab === 'pat' ? 'on' : ''}">패턴 회화</button></div>`;
  if (V.wordTab === 'pat') return patView(seg);
  const LV = {1: '초등', 2: '중학', 3: '고등'}[D.words.level];
  const total = V.queue.length, done = Math.min(V.qi, total);
  const head = `<div class="crumb">Words / ${LV} 기본 어휘<span class="r">외운 단어 <b class="num" style="color:var(--ink)">${D.words.learned}</b></span></div>${seg}
    <div class="prog"><i style="width:${total ? done / total * 100 : 100}%"></i></div>`;
  if (V.qi >= total) {
    const t = dayNum(), next = Object.values(D.words.items).filter(x => x.b < 5 && x.d > t).map(x => x.d).sort((a, b) => a - b)[0];
    return `<main class="page">${head}<div class="wcard"><div class="ko">오늘 단어 끝!</div>
      <div class="pr">오늘 ${total}개를 했어요.${next !== undefined ? ` 다음 복습은 <b>${rel(next)}</b> 돌아와요.` : ''}</div>
      <div class="dock"><button class="b1 big" data-act="more">새 단어 5개 더</button><button class="b1 big dark" data-menu="plan">계획으로</button></div></div></main>`;
  }
  const it = V.queue[V.qi], e = it.e, cur = D.words.items[e.w] || {b: 0};
  const steps = [1, 2, 3, 4, 5].map(i => `<i class="${cur.b >= i ? 'on' : ''}"></i>`).join('');
  const nextBox = Math.min(5, cur.b + 1);
  return `<main class="page">${head}
    <div class="wcard">
      <div class="steps">${it.isNew ? '새 단어' : '복습'} · ${steps}</div>
      <div class="en">${esc(e.w)}</div>
      <div class="pr">[${esc(e.pr)}] <span class="pos">${esc(e.pos)}</span></div>
      ${V.show ? `<div class="ko">${esc(e.ko.replace(/\s*;\s*/g, ' · '))}</div>` : ''}
      <div class="heard">${done + 1} / ${total}</div>
    </div>
    <div class="dock"><button class="b1 big" data-act="listen">소리 듣기</button>
      ${V.show ? `<button class="b1 big" data-grade="0">몰랐어요<small>10분 뒤 다시 · 1</small></button>
        <button class="b1 big" data-grade="1">헷갈려요<small>내일 · 2</small></button>
        <button class="b1 big dark" data-grade="2">알았어요<small>${nextBox >= 5 ? '외운 단어로' : BOXN[nextBox] + ' 뒤'} · 3</small></button>`
      : `<button class="b1 big dark" data-act="reveal">뜻 보기<small>스페이스</small></button>`}</div></main>`;
}
function showWord() { const it = V.queue && V.queue[V.qi]; if (it && V.menu === 'words' && V.wordTab === 'card') S.speak(it.e.w); }
function grade(g) {
  markStudy();
  const it = V.queue[V.qi]; if (!it) return;
  const W = D.words, t = dayNum(), cur = W.items[it.e.w] || {b: 0, d: t};
  if (it.isNew) { W.newCount++; it.isNew = false; }
  if (g === 0) { cur.b = 0; cur.d = t; V.queue.push({e: it.e, isNew: false}); }
  else if (g === 1) { cur.b = Math.max(1, cur.b); cur.d = t + 1; }
  else { cur.b = Math.min(5, cur.b + 1); cur.d = t + GAP[cur.b]; if (cur.b === 5) W.learned++; }
  W.items[it.e.w] = cur; save();
  V.qi++; V.show = false; render(); showWord();
}

// ---------- 패턴 회화 (회장님 2026-10-25 "문장 따라 하기는 패턴 익히는 회화책 수준으로, 패턴 익히기 강화") ----------
// 패턴 하나 = ① 익히기(뜻·쓰는 법·예문 6개 듣기) → ② 따라 말하기(예문 6개, 틀린 단어 빨강) → ③ 바꿔 말하기(한국어를 보고 패턴으로 영어로, 3문제)
// 따라 말하기 6개 모두 + 바꿔 말하기 2개 이상이면 '익힘', 그다음 3·7·14·30일 뒤 '복습'으로 다시 나온다.
function wordsOf(s) {
  return s.toLowerCase().replace(/’/g, "'")
    .replace(/\bi'd\b/g, 'i would').replace(/\bi'm\b/g, 'i am').replace(/\bi'll\b/g, 'i will').replace(/\bi've\b/g, 'i have').replace(/\bit's\b/g, 'it is')
    .replace(/\bwhat's\b/g, 'what is').replace(/\bthat's\b/g, 'that is').replace(/\bwhere's\b/g, 'where is').replace(/\bthere's\b/g, 'there is')
    .replace(/\bhe's\b/g, 'he is').replace(/\bshe's\b/g, 'she is').replace(/\byou're\b/g, 'you are').replace(/\bwe're\b/g, 'we are').replace(/\bthey're\b/g, 'they are')
    .replace(/\bdon't\b/g, 'do not').replace(/\bdidn't\b/g, 'did not').replace(/\bdoesn't\b/g, 'does not').replace(/\bcan't\b/g, 'can not').replace(/\bcannot\b/g, 'can not')
    .replace(/\bisn't\b/g, 'is not').replace(/\baren't\b/g, 'are not').replace(/\bhaven't\b/g, 'have not').replace(/\bwon't\b/g, 'will not').replace(/\bwe'll\b/g, 'we will')
    .replace(/\bwanna\b/g, 'want to').replace(/\bgonna\b/g, 'going to').replace(/\blet us\b/g, "let's")
    .replace(/\bten\b/g, '10').replace(/\bfourteen\b/g, '14')
    .replace(/[^a-z0-9' ]/g, ' ').trim().split(/\s+/).filter(Boolean);
}
function hits(target, said) {
  const a = wordsOf(target), b = wordsOf(said), n = a.length, m = b.length;
  const d = Array.from({length: n + 1}, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) d[i][j] = a[i] === b[j] ? d[i + 1][j + 1] + 1 : Math.max(d[i + 1][j], d[i][j + 1]);
  const ok = new Array(n).fill(false);
  for (let i = 0, j = 0; i < n && j < m;) { if (a[i] === b[j]) { ok[i] = true; i++; j++; } else if (d[i + 1][j] >= d[i][j + 1]) i++; else j++; }
  return ok;
}
function marked(target, said) {
  const ok = hits(target, said); let k = 0;
  return target.split(' ').map(p => {
    const n = wordsOf(p).length; let bad = false;
    for (let x = 0; x < n; x++) if (!ok[k + x]) bad = true;
    k += n;
    return bad ? `<span class="bad">${esc(p)}</span>` : esc(p);
  }).join(' ');
}
/** 바꿔 말하기 판정: 낱말 묶음마다 하나 이상 들어 있으면 맞음. */
function drillPass(dr, said) {
  const norm = ' ' + wordsOf(said).join(' ') + ' ';
  return dr.need.every(g => g.some(alt => norm.includes(' ' + wordsOf(alt).join(' ') + ' ')));
}

let PAT = null;
const REV = [3, 7, 14, 30];
const pst = id => D.pat[id] || (D.pat[id] = {say: [], drill: [], done: 0, rev: 0, lv: 0});
const sayCount = st => st.say.filter(Boolean).length;
const drillCount = st => st.drill.filter(Boolean).length;
const mastered = (p, st) => sayCount(st) >= p.ex.length && drillCount(st) >= 2;
const dueRev = st => st.done && st.rev && st.rev <= dayNum();
function patToday() {
  if (!PAT) return null;
  return PAT.find(p => dueRev(pst(p.id))) || PAT.find(p => !pst(p.id).done) || null;
}

function patView(seg) {
  if (!PAT) return `<main class="page">${seg}<div class="wcard"><div class="pr">패턴을 여는 중…</div></div></main>`;
  const P = V.pat;
  if (P.id === null) return patList(seg);
  const p = PAT.find(x => x.id === P.id), st = pst(p.id);
  const steps = [['learn', '① 익히기'], ['say', `② 따라 말하기 ${sayCount(st)}/${p.ex.length}`], ['drill', `③ 바꿔 말하기 ${drillCount(st)}/${p.drill.length}`]]
    .map(([k, l]) => `<button data-pstep="${k}" class="${P.view === k ? 'on' : ''}">${l}</button>`).join('');
  const head = `<div class="crumb">Words / 패턴 회화 · ${esc(p.sit)}<span class="r"><button class="b1 ghost" data-act="pat-list">목록</button></span></div>
    <div class="seg">${steps}</div>`;
  if (P.view === 'learn') {
    const ex = p.ex.map(([en, ko], i) => `<button class="exrow" data-pex="${i}"><span class="ck ${st.say[i] ? 'on' : ''}"></span><span class="exen">${esc(en)}</span><span class="exko">${esc(ko)}</span></button>`).join('');
    return `<main class="page">${head}
      <div class="scroll grow"><div class="pathead"><div class="patbig">${esc(p.pattern)}</div><div class="patmean">${esc(p.mean)}</div><div class="pattip">${esc(p.tip)}</div></div>
        <div class="exlist">${ex}</div></div>
      <div class="dock"><button class="b1 big" data-act="pat-all">예문 모두 듣기</button><button class="b1 big dark" data-pstep="say">따라 말하기 시작</button></div></main>`;
  }
  if (P.view === 'done') {
    const ok = mastered(p, st);
    const next = PAT.find(x => x.id !== p.id && (dueRev(pst(x.id)) || !pst(x.id).done));
    return `<main class="page">${head}<div class="wcard">
      <div class="ko">${ok ? '이 패턴을 익혔어요' : '조금만 더!'}</div>
      <div class="patbig" style="font-size:3vw">${esc(p.pattern)}</div>
      <div class="pr">따라 말하기 ${sayCount(st)}/${p.ex.length} · 바꿔 말하기 ${drillCount(st)}/${p.drill.length}${ok && st.rev ? ` · 복습은 <b>${rel(st.rev)}</b>` : ''}</div></div>
      <div class="dock"><button class="b1 big" data-pstep="${ok ? 'learn' : (sayCount(st) < p.ex.length ? 'say' : 'drill')}">${ok ? '다시 보기' : '이어서 하기'}</button>
        ${next ? `<button class="b1 big dark" data-popen="${next.id}">다음 패턴</button>` : '<button class="b1 big dark" data-act="pat-list">목록</button>'}</div></main>`;
  }
  const say = P.view === 'say';
  const n = say ? p.ex.length : p.drill.length, i = Math.min(P.i, n - 1);
  let body;
  if (say) {
    const [en, ko] = p.ex[i];
    body = `<div class="steps">${p.ex.map((_, k) => `<i class="${st.say[k] ? 'on' : ''}"></i>`).join('')}</div>
      <div class="sent">${P.said ? marked(en, P.said) : esc(en)}</div><div class="pr">${esc(ko)}</div>
      <div class="heard ${P.ok ? 'ok' : ''}">${P.said ? `들린 말: "${esc(P.said)}" · ${P.ok ? '완벽해요!' : '빨간 단어를 다시 말해 봐요'}` : V.rec ? '듣고 있어요…' : '원어민 소리를 듣고, 아래 큰 버튼(또는 스페이스)을 누르고 따라 말해요'}</div>`;
  } else {
    const dr = p.drill[i];
    body = `<div class="steps">${p.drill.map((_, k) => `<i class="${st.drill[k] ? 'on' : ''}"></i>`).join('')}</div>
      <div class="pr">패턴 <b>${esc(p.pattern)}</b> 으로 영어로 말해 보세요</div>
      <div class="ko" style="font-size:2.8vw">${esc(dr.ko)}</div>
      <div class="heard ${P.ok ? 'ok' : ''}">${P.said ? (P.ok ? `<b>맞았어요!</b> "${esc(P.said)}"` : `<b class="bad-t">다시 해 볼까요?</b> 들린 말: "${esc(P.said)}"`) : V.rec ? '듣고 있어요…' : ''}</div>
      ${P.said || P.hint ? `<div class="model">${P.ok ? '예시' : '이렇게 말해요'} · <span>${esc(dr.model)}</span></div>` : ''}`;
  }
  return `<main class="page">${head}<div class="wcard">${body}</div>
    <div class="dock">${say ? `<button class="b1 big" data-act="pat-listen">원어민 듣기</button>` : `<button class="b1 big" data-act="pat-hint" ${P.hint || P.said ? 'disabled' : ''}>힌트</button>`}
      <button class="mic ${V.rec ? 'rec' : ''}" data-act="rec">${V.rec ? '듣는 중' : '말하기'}</button>
      <button class="b1 big ${P.ok ? 'dark' : ''}" data-act="pat-next">${i + 1 >= n ? '끝내기' : P.ok ? '다음' : '넘어가기'}<small>${i + 1}/${n} · Enter</small></button></div></main>`;
}

function patList(seg) {
  const sits = ['전체', ...new Set(PAT.map(p => p.sit))];
  const chips = sits.map(s => `<button class="chip ${V.pat.sit === s ? 'on' : ''}" data-psit="${esc(s)}">${esc(s)}</button>`).join('');
  const done = PAT.filter(p => pst(p.id).done).length;
  const today = patToday();
  const row = p => {
    const st = pst(p.id);
    const status = dueRev(st) ? '<span class="due">복습</span>' : st.done ? '<span class="due later">익힘 ✓</span>'
      : sayCount(st) || drillCount(st) ? `<span class="due later">따라 ${sayCount(st)}/${p.ex.length} · 바꿔 ${drillCount(st)}/${p.drill.length}</span>` : '<span class="due later">시작</span>';
    return `<button class="prow" data-popen="${p.id}"><span class="pp">${esc(p.pattern)}</span><span class="pm">${esc(p.mean)}</span>${status}</button>`;
  };
  const list = V.pat.sit === '전체'
    ? sits.slice(1).map(s => `<div class="grp">${esc(s)}</div>${PAT.filter(p => p.sit === s).map(row).join('')}`).join('')
    : PAT.filter(p => p.sit === V.pat.sit).map(row).join('');
  return `<main class="page"><div class="crumb">Words / 패턴 회화<span class="r">익힌 패턴 <b class="num">${done}/${PAT.length}</b></span></div>${seg}
    ${today ? `<button class="today" data-popen="${today.id}"><span class="tl">${dueRev(pst(today.id)) ? '오늘 복습할 패턴' : '오늘의 패턴'}</span><span class="pp">${esc(today.pattern)}</span><span class="pm">${esc(today.mean)}</span><span class="b1 dark">시작</span></button>` : ''}
    <div class="chips">${chips}</div>
    <div class="list scroll grow">${list}</div></main>`;
}

function patOpen(id) { V.pat.id = id; V.pat.view = 'learn'; V.pat.i = 0; V.pat.said = ''; V.pat.ok = null; V.pat.hint = false; render(); }
function patStep(view) {
  const p = PAT.find(x => x.id === V.pat.id), st = pst(p.id);
  V.pat.view = view; V.pat.said = ''; V.pat.ok = null; V.pat.hint = false;
  // 아직 안 한 것부터
  V.pat.i = view === 'say' ? Math.max(0, p.ex.findIndex((_, k) => !st.say[k])) : view === 'drill' ? Math.max(0, p.drill.findIndex((_, k) => !st.drill[k])) : 0;
  render();
  if (view === 'say') S.speak(p.ex[V.pat.i][0]);
}
function patNext() {
  const P = V.pat, p = PAT.find(x => x.id === P.id); if (!p) return;
  const n = P.view === 'say' ? p.ex.length : p.drill.length;
  P.said = ''; P.ok = null; P.hint = false;
  if (P.i + 1 < n) { P.i++; render(); if (P.view === 'say') S.speak(p.ex[P.i][0]); return; }
  if (P.view === 'say') { patStep('drill'); return; }
  patFinish(p);
}
function patFinish(p) {
  const st = pst(p.id);
  if (mastered(p, st)) {
    const wasDue = dueRev(st);
    if (!st.done) { st.done = dayNum(); st.lv = 0; }
    else if (wasDue) st.lv = Math.min(REV.length - 1, (st.lv || 0) + 1);
    st.rev = dayNum() + REV[st.lv || 0];
    if (wasDue) { st.drill = []; } // 복습 땐 바꿔 말하기를 다시 채우게
  }
  save();
  V.pat.view = 'done'; render();
}
function patHeard(text) {
  const P = V.pat, p = PAT.find(x => x.id === P.id), st = pst(p.id);
  P.said = text;
  if (P.view === 'say') {
    P.ok = hits(p.ex[P.i][0], text).every(Boolean);
    if (P.ok) { st.say[P.i] = 1; markStudy(); save(); }
    render();
    if (P.ok) { const id = P.id, i = P.i; setTimeout(() => { if (V.pat.id === id && V.pat.i === i && V.pat.ok && V.menu === 'words') patNext(); }, 1500); }
  } else {
    P.ok = drillPass(p.drill[P.i], text);
    if (P.ok) { st.drill[P.i] = 1; markStudy(); save(); }
    render();
  }
}

function startRec() {
  if (V.rec) { S.stopListen(); V.rec = false; render(); return; }
  V.rec = true; V.pat.said = ''; V.pat.ok = null; render();
  S.listen(V.menu === 'ask' ? 'ko-KR' : 'en-US');
}
window.steadyListening = () => { V.rec = true; };
window.steadyHeard = text => {
  V.rec = false;
  if (V.menu === 'ask') { V.ask.said = (V.ask.said ? V.ask.said + ' ' : '') + text; render(); return; }
  if (V.menu === 'words' && V.wordTab === 'pat' && PAT && V.pat.id !== null) { patHeard(text); return; }
  render();
};
window.steadyListenFail = why => { V.rec = false; render(); if (why) toast(why); };

// ================= Review =================
const dueReviews = () => D.reviews.filter(r => r.due <= dayNum());
const img = n => n ? `/img/${encodeURIComponent(n)}` : '';
function thumb(r) { return r.img ? `<span class="thumb"><img alt="" src="${img(r.img)}"></span>` : `<span class="thumb"><span>${esc(r.s)}</span></span>`; }
function review() {
  if (V.adding) return addView();
  if (V.reviewOpen !== null) return solveView();
  const t = dayNum(), due = dueReviews(), later = D.reviews.filter(r => r.due > t).sort((a, b) => a.due - b.due);
  const item = r => swRow(`review:${r.id}`, `<button class="item" data-open="${r.id}">${thumb(r)}<span>${esc(r.src)}<small>${esc(r.s)} · 틀린 횟수 ${r.wrong} · 연속 맞음 ${r.streak}/3</small></span><span class="due ${r.due > t ? 'later' : ''}">${rel(r.due)}</span></button>`);
  return `<main class="page"><div class="crumb">Review / 다시 풀 문제<span class="r">끝낸 문제 <b class="num" style="color:var(--ink)">${D.done.length}</b></span></div>
    <h3 class="title">오답</h3>
    <div class="btns"><button class="b1 big dark" data-act="add-camera">사진 찍어 넣기</button><button class="b1 big" data-act="add-gallery">사진 고르기</button><button class="b1 big" data-act="add-pen">S펜으로 쓰기</button></div>
    <div class="list scroll grow">${due.length ? `<div class="grp">오늘 다시 풀기 ${due.length}</div>${due.map(item).join('')}` : '<div class="grp">오늘 풀 오답이 없어요</div>'}
      ${later.length ? `<div class="grp">다음에</div>${later.map(item).join('')}` : ''}
      ${!D.reviews.length ? '<div class="empty">틀린 문제를 사진이나 S펜으로 넣으면, 잊을 때쯤 다시 풀게 해 줘요. 왼쪽으로 밀면 지울 수 있어요.</div>' : ''}</div></main>`;
}
function addView() {
  const subj = ['국어', '수학', '영어', '과학', '사회', '기타'].map(s => `<button class="chip ${V.addSubj === s ? 'on' : ''}" data-subj="${s}">${s}</button>`).join('');
  if (V.adding === 'pen') {
    const colors = [['#191919', '검정'], ['#d44c47', '빨강']].map(([c, l]) => `<button class="chip ${pad.color === c ? 'on' : ''}" data-pen="${c}">${l}</button>`).join('');
    const tools = `<div class="btns"><div class="chips">${colors}</div><button class="b1 ghost" data-act="pad-undo">한 획 지우기</button><button class="b1 ghost" data-act="pad-clear">모두 지우기</button>
      <span class="subc" style="font-size:1.25vw">${pad.bg ? '사진 위에 틀린 곳·풀이를 써요' : 'S펜이나 손가락으로 문제를 옮겨 적어요'}</span></div>`;
    if (pad.editId) return `<main class="page"><div class="crumb">Review / S펜으로 쓰기</div><canvas class="pad" id="pad"></canvas>${tools}
      <div class="btns"><span style="flex:1"></span><button class="b1" data-act="add-cancel">취소</button><button class="b1 dark" data-act="pad-save">저장</button></div></main>`;
    return `<main class="page"><div class="crumb">Review / ${pad.bg ? '사진에 S펜으로 표시' : 'S펜으로 쓰기'}</div><canvas class="pad" id="pad"></canvas>${tools}
      <div class="line"><span class="subc" style="font-size:1.35vw">과목</span><div class="chips">${subj}</div></div>
      <form class="line" id="addr"><input id="src" placeholder="어디서 틀렸어요? (예: 학원 숙제 p.52 3번, 비워도 돼요)" maxlength="60">
        <button type="button" class="b1" data-act="add-cancel">취소</button><button class="b1 dark">저장 · 내일 다시</button></form></main>`;
  }
  return `<main class="page"><div class="crumb">Review / 사진으로 넣기</div>
    <div class="problem">${V.addImg ? `<img alt="" src="${img(V.addImg)}">` : '<div class="q">사진을 기다리는 중…</div>'}</div>
    <div class="btns">${V.addImg ? '<button class="b1" data-act="photo-pen">S펜으로 표시하기</button><button class="b1 ghost" data-act="add-camera">다시 찍기</button>' : ''}</div>
    <div class="line"><span class="subc" style="font-size:1.35vw">과목</span><div class="chips">${subj}</div></div>
    <form class="line" id="addr"><input id="src" placeholder="어디서 틀렸어요? (예: 학원 숙제 p.52 3번, 비워도 돼요)" maxlength="60">
      <button type="button" class="b1" data-act="add-cancel">취소</button><button class="b1 dark">저장 · 내일 다시</button></form></main>`;
}
function solveView() {
  const r = D.reviews.find(x => x.id === V.reviewOpen); if (!r) { V.reviewOpen = null; return review(); }
  return `<main class="page"><div class="crumb">Review / ${esc(r.s)} · ${esc(r.src)}<span class="r">틀린 횟수 ${r.wrong} · 연속 맞음 ${r.streak}/3</span></div>
    <div class="problem">${r.img ? `<img alt="" src="${img(r.img)}">` : `<div class="q">${esc(r.src)}${r.url ? `<br>${siteOf(r.url).name}에서 다시 보고 풀어요` : ''}</div>`}</div>
    ${r.answer ? `<div class="answer"><b>AI 답</b>\n${esc(r.answer)}</div>` : ''}
    <div class="btns"><button class="b1 ghost" data-act="r-back">목록</button>${r.url ? `<button class="b1" data-act="r-ebs">${siteOf(r.url).name}에서 보기</button>` : ''}<button class="b1" data-act="r-ask">질문하기</button><button class="b1" data-act="r-pen">S펜으로 쓰기</button>
      <span style="flex:1"></span>
      <button class="b1 big" data-act="r-wrong">또 틀렸어요<small>내일 다시</small></button>
      <button class="b1 big dark" data-act="r-right">맞았어요<small>${r.streak >= 2 ? '끝낸 문제로' : r.streak === 1 ? '7일 뒤' : '3일 뒤'}</small></button></div></main>`;
}
// S펜: 획을 기록해 두고(한 획 지우기) 배경 사진(있으면) 위에 다시 그린다 — 회장님 0.2.2 시험: "찍은 사진 위에 S펜으로 쓰기"
let pad = {bg: '', strokes: [], color: '#191919', editId: null};
function padReset() { pad = {bg: '', strokes: [], color: '#191919', editId: null}; }
function padStart(bg, editId) { pad = {bg: bg || '', strokes: [], color: bg ? '#d44c47' : '#191919', editId: editId || null}; V.adding = 'pen'; render(); }
function bindPad() {
  const c = $('#pad'); if (!c) return;
  const r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  c.width = Math.round(r.width * dpr); c.height = Math.round(r.height * dpr);
  const g = c.getContext('2d');
  let bgImg = null;
  const seg = (st, i) => { g.strokeStyle = st.color; g.lineWidth = st.w[i] * dpr; g.beginPath(); g.moveTo(st.pts[i - 1][0] * c.width, st.pts[i - 1][1] * c.height); g.lineTo(st.pts[i][0] * c.width, st.pts[i][1] * c.height); g.stroke(); };
  const redraw = () => {
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    if (bgImg) { const k = Math.min(c.width / bgImg.width, c.height / bgImg.height), w = bgImg.width * k, h = bgImg.height * k; g.drawImage(bgImg, (c.width - w) / 2, (c.height - h) / 2, w, h); }
    g.lineCap = 'round'; g.lineJoin = 'round';
    pad.strokes.forEach(st => { for (let i = 1; i < st.pts.length; i++) seg(st, i); });
  };
  pad.redraw = redraw; pad.canvas = c;
  redraw();
  if (pad.bg) { const im = new Image(); im.onload = () => { bgImg = im; redraw(); }; im.onerror = () => toast('사진을 불러오지 못했어요'); im.src = img(pad.bg); }
  let cur = null;
  const pos = e => { const b = c.getBoundingClientRect(); return [(e.clientX - b.left) / b.width, (e.clientY - b.top) / b.height]; };
  c.onpointerdown = e => { c.setPointerCapture(e.pointerId); cur = {color: pad.color, pts: [pos(e)], w: [0]}; pad.strokes.push(cur); };
  c.onpointermove = e => {
    if (!cur) return;
    cur.pts.push(pos(e)); cur.w.push(e.pointerType === 'pen' ? 1.5 + (e.pressure || .5) * 4 : 3);
    g.lineCap = 'round'; g.lineJoin = 'round'; seg(cur, cur.pts.length - 1);
  };
  c.onpointerup = c.onpointercancel = () => { cur = null; };
}
/** 그린 것을 파일로 저장하고 이름을 돌려준다 (사진 위면 JPEG, 빈 종이면 PNG). */
function padSave() {
  if (!pad.canvas) return '';
  return S.saveImage(pad.canvas.toDataURL(pad.bg ? 'image/jpeg' : 'image/png', .88));
}
window.steadyPhoto = name => {
  if (V.menu === 'ask') { V.ask.img = name; V.ask.from = null; render(); return; }
  V.addImg = name; render();
};
window.steadyPhotoFail = why => { if (V.adding && !V.addImg && V.adding !== 'pen') V.adding = null; render(); if (why) toast(why); };

// ================= Ask =================
let AIS = [];
function aiApps() { try { AIS = JSON.parse(S.aiApps()).filter(a => a.installed); } catch (e) { AIS = []; } if (!V.ask.ai && AIS.length) V.ask.ai = AIS[0].key; }
function askPrompt() {
  const A = V.ask, r = A.from ? D.reviews.find(x => x.id === A.from) : null;
  const mode = {hint: '답을 바로 말하지 말고, 힌트부터 한 단계씩 알려 줘. 내가 다음 단계를 물어보면 이어서 알려 줘.',
    full: '풀이 과정을 단계별로 자세히 알려 줘.', similar: '이 문제와 같은 개념의 비슷한 문제 3개를 내 줘. 답과 풀이는 맨 아래에 따로.'}[A.mode];
  return `[공부 질문${r ? ' · ' + r.s : ''}]\n문제: ${A.img ? '(사진 첨부)' : '(사진 없음)'}${r ? ' ' + r.src : ''}\n내가 막힌 곳: ${A.said || '…'}\n${mode}`;
}
function ask() {
  const A = V.ask;
  if (A.sent) {
    const ai = AIS.find(a => a.key === A.ai) || {name: 'AI'};
    return `<main class="page"><div class="crumb">Ask / ${esc(ai.name)}에서 돌아왔어요</div><h3 class="title">답 가져오기</h3>
      <p class="subc" style="font-size:1.4vw;margin:0">${esc(ai.name)} 앱에서 답을 길게 눌러 복사한 뒤, 아래 [붙여넣기]를 눌러요.</p>
      ${A.answer ? `<div class="answer grow">${esc(A.answer)}</div>` : '<div class="empty">아직 붙여 넣은 답이 없어요</div>'}
      <div class="btns"><button class="b1 big" data-act="paste">붙여넣기</button>
        ${A.answer ? `<button class="b1 big dark" data-act="save-ans">${A.from ? '이 문제 오답에 같이 저장' : '질문 기록에 저장'}</button>` : ''}
        <button class="b1 big" data-act="send">${esc(ai.name)} 다시 열기</button><button class="b1 ghost" data-act="ask-new">새 질문</button></div></main>`;
  }
  const r = A.from ? D.reviews.find(x => x.id === A.from) : null;
  const modes = [['hint', '힌트부터'], ['full', '풀이 전체'], ['similar', '비슷한 문제 3개']].map(([k, l]) => `<button class="chip ${A.mode === k ? 'on' : ''}" data-mode="${k}">${l}</button>`).join('');
  const ais = AIS.map(a => `<button class="chip ${A.ai === a.key ? 'on' : ''}" data-ai="${a.key}">${esc(a.name)}</button>`).join('');
  const hist = D.asked.slice(0, 3).map(h => `· ${esc(h.q)} <span class="num">(${esc(h.ai)})</span>`).join('<br>');
  return `<main class="page"><div class="crumb">Ask / 모르는 문제만 물어봐요</div><h3 class="title">질문</h3>
    <div class="line"><span class="stepno">1</span><span style="font-size:1.45vw">문제</span>
      ${A.img || r ? `${A.img ? `<span class="thumb" style="width:8vw"><img alt="" src="${img(A.img)}"></span>` : ''}<span class="tag" style="margin:0">${esc(r ? r.s + ' · ' + r.src : '찍은 사진')}</span><button class="b1 ghost" data-act="ask-clear">빼기</button>`
      : '<button class="b1" data-act="ask-pick">오답에서 고르기</button><button class="b1" data-act="ask-cam">사진 찍기</button>'}</div>
    <div class="line"><span class="stepno">2</span><button class="mic ${V.rec ? 'rec' : ''}" data-act="rec" style="width:6.4vw;height:6.4vw;font-size:1.25vw">${V.rec ? '듣는 중' : '말로 묻기'}</button>
      <textarea class="said" id="said" placeholder="어디서 막혔는지 말하거나 써요">${esc(A.said)}</textarea></div>
    <div class="line"><span class="stepno">3</span><div class="chips">${modes}</div></div>
    <div class="line"><span class="stepno">4</span>${ais ? `<div class="chips">${ais}</div>` : '<span class="subc" style="font-size:1.3vw">이 태블릿에 AI 앱이 없어요. 보호자가 잠금을 잠깐 끄고 플레이스토어에서 ChatGPT나 Gemini를 깔면 여기 나와요.</span>'}
      ${ais ? `<button class="b1 big dark" data-act="send" style="margin-left:auto">보내기</button>` : ''}</div>
    ${A.said ? `<div class="prompt">${esc(askPrompt())}</div>` : hist ? `<div class="hist"><b>최근 질문</b><br>${hist}</div>` : ''}</main>`;
}

// ================= 설정 =================
let INFO = {};
function refreshInfo() { try { INFO = JSON.parse(S.info()); } catch (e) { INFO = {}; } }
window.steadyInfo = s => { try { INFO = JSON.parse(s); } catch (e) { INFO = {}; } render(); };
function settings() {
  const b = S.brightness(), vol = S.volume();
  const row = (l, r) => `<div class="srow"><div class="l">${l}</div>${r || ''}</div>`;
  const lv = [[1, '초등'], [2, '중학'], [3, '고등']].map(([v, l]) => `<button class="chip ${D.words.level === v ? 'on' : ''}" data-level="${v}">${l}</button>`).join('');
  const per = [5, 10, 15, 20].map(v => `<button class="chip ${D.words.perDay === v ? 'on' : ''}" data-per="${v}">${v}개</button>`).join('');
  const lock = !INFO.owner ? row('<span class="subc">꺼짐 — 보통 앱으로 깔려 있어요. 공장 초기화 뒤 QR로 설치하면 켜져요</span>')
    : row(INFO.lock ? '켜짐 — 스테디 말고는 열리지 않아요' : '잠깐 꺼 둠 — 다른 앱을 쓸 수 있어요', `<button class="b1" data-act="lock">${INFO.lock ? '잠금 끄기' : '잠금 켜기'}</button>`)
      + row('관리를 끝내고 보통 태블릿으로 되돌리기', '<button class="b1 ghost" data-act="release">관리 끝내기</button>');
  return `<main class="page"><div class="crumb">설정</div><h3 class="title">설정</h3><div class="set scroll grow">
    <div class="sec">와이파이 · 밝기 · 소리</div>
    ${row(`와이파이 &nbsp; <span class="subc">${esc(S.net())}</span>`, '<button class="b1" data-act="wifi">와이파이 연결</button>')}
    ${row('밝기', `<input type="range" min="5" max="100" value="${b < 0 ? 60 : Math.round(b * 100)}" data-range="bright"><button class="b1 ghost" data-act="bright-auto">태블릿 설정대로</button>`)}
    ${row('소리', `<input type="range" min="0" max="100" value="${Math.round(vol * 100)}" data-range="vol">`)}
    <div class="sec">시험</div>
    ${row(D.exam.date ? `${esc(D.exam.name || '시험')} · ${esc(D.exam.date)} · <span class="warm num">${dday()}</span>` : '<span class="subc">시험 날짜가 없어요</span>', '<button class="b1" data-act="exam">바꾸기</button>')}
    <div class="sec">단어</div>
    ${row('단어장', `<div class="chips">${lv}</div>`)}${row('하루 새 단어', `<div class="chips">${per}</div>`)}
    <div class="sec">학생</div>
    ${row(`이름 &nbsp; <span class="subc">${esc(D.name || '아직 없음')}</span>`, '<button class="b1" data-act="name">바꾸기</button>')}
    <div class="sec">보호자</div>
    ${row(INFO.hasPin ? '보호자 비밀번호 있음' : '보호자 비밀번호가 없어요', `<button class="b1" data-act="pin">${INFO.hasPin ? '바꾸기' : '정하기'}</button>`)}
    <div class="sec">공부 전용 잠금</div>${lock}
    <div class="sec">업데이트</div>
    ${row(`앱 ${esc(INFO.version)} · 화면 ${esc(INFO.web)}`, '<button class="b1" data-act="update">업데이트 확인</button>')}
    <div class="sec">이 태블릿 점검</div><div class="mono">${esc(S.check())}
화면 엔진: 크롬 ${esc(ENGINE)}${+ENGINE && +ENGINE < 84 ? ' (오래됨 — Play 스토어에서 Android System WebView 를 업데이트하면 더 빠르고 안정적이에요)' : ' ✓'}</div>
    <div class="sec">자료 출처</div>${row('영한 단어장: 국립국어원·위키낱말사전 기반 편집본 (CC BY-SA)', '<button class="b1 ghost" data-act="about">자세히</button>')}
    <div class="sec">최근 기록</div><div class="mono">${esc(S.log() || '없음')}</div>
  </div></main>`;
}

// ================= 그리기 =================
function render() {
  if (V.menu === 'ask') aiApps();
  const page = {home, plan, words, review, ask, settings}[V.menu]();
  $('#app').innerHTML = V.menu === 'home' ? page : `<div class="app">${side()}${page}</div>`;
  if (V.timer) tickTimer();
  if (V.menu === 'review' && V.adding === 'pen') bindPad();
}

// ================= 누르기 =================
// 밀어서 지우기 (회장님 2026-10-25 "길게 눌러 지우기는 불편, 아이폰처럼 왼쪽으로 밀면 삭제 단추") — 할 일·오답·달력 메모 같은 방식.
// 줄 = <div class="sw" data-sw="종류:id"><div class="sw-in">…</div><button class="sw-del" data-del="종류:id">삭제</button></div>
// 왼쪽으로 밀면 [삭제]가 나오고 끝까지 밀면 바로 지움(되돌리기 있음). 열린 줄이 있을 때 다른 곳을 누르면 닫기만 함 — 아이폰과 같게.
let pressed = false; // 민 뒤·닫기만 한 뒤의 눌림은 버튼으로 치지 않음
const SW = {el: null, x0: 0, y0: 0, base: 0, dx: 0, mode: '', open: null};
const swRow = (id, inner) => `<div class="sw" data-sw="${id}"><div class="sw-in">${inner}</div><button type="button" class="sw-del" data-del="${id}">삭제</button></div>`;
const swW = () => window.innerWidth * 0.09; // [삭제] 너비 = app.css .sw-del 9vw
function swSet(el, x, anim) {
  const i = el.querySelector('.sw-in'); if (!i) return;
  i.style.transition = anim ? 'transform .2s ease' : 'none';
  i.style.transform = x ? `translateX(${x}px)` : '';
  el.classList.toggle('open', x < 0);
}
function swClose() { if (SW.open && SW.open.isConnected) swSet(SW.open, 0, true); SW.open = null; }
function swDelete(id) {
  SW.open = null;
  const kind = id.split(':')[0], n = +id.split(':')[1];
  if (kind === 'todo') deleteTodo(n);
  else if (kind === 'review') deleteReview(n);
  else if (kind === 'memo' && V.sheet && V.sheet.data.key) memoDel(V.sheet.data.key, n);
}
document.addEventListener('pointerdown', e => {
  pressed = false;
  if (SW.open && !SW.open.isConnected) SW.open = null; // 화면을 다시 그려 사라진 줄
  const el = e.target.closest('.sw');
  if (SW.open && !(SW.open === el && e.target.closest('.sw-del'))) { swClose(); pressed = true; return; } // [삭제] 말고 어디를 눌러도 열린 줄만 닫음
  if (!el || e.target.closest('.sw-del')) return;
  SW.el = el; SW.x0 = e.clientX; SW.y0 = e.clientY; SW.base = 0; SW.dx = 0; SW.mode = '';
});
document.addEventListener('pointermove', e => {
  if (!SW.el) return;
  const dx = e.clientX - SW.x0, dy = e.clientY - SW.y0;
  if (!SW.mode) {
    if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy)) SW.mode = 'x';
    else if (Math.abs(dy) > 8) { SW.el = null; return; } // 위아래로 움직이면 목록 넘기기
    else return;
  }
  SW.dx = dx;
  swSet(SW.el, Math.min(0, SW.base + dx), false);
});
document.addEventListener('pointerup', () => {
  const el = SW.el; SW.el = null;
  if (!el || SW.mode !== 'x') return;
  pressed = true;
  const x = Math.min(0, SW.base + SW.dx), w = el.offsetWidth;
  if (x < -w * 0.5) { swDelete(el.dataset.sw); return; } // 끝까지 밀면 바로 지움
  if (x < -swW() / 2) { swSet(el, -swW(), true); SW.open = el; } else swSet(el, 0, true);
});
document.addEventListener('pointercancel', () => { if (SW.el) swSet(SW.el, 0, true); SW.el = null; });

let undoFn = null;
function deleteTodo(id) {
  const list = todos(), i = list.findIndex(x => x.id === id); if (i < 0) return;
  const [t] = list.splice(i, 1); save(); render();
  undoFn = () => { list.splice(i, 0, t); save(); render(); };
  toast(`‘${t.t}’ 지웠어요`, true);
}
function deleteReview(id) {
  const i = D.reviews.findIndex(x => x.id === id); if (i < 0) return;
  const [r] = D.reviews.splice(i, 1); save(); render();
  let undone = false;
  undoFn = () => { undone = true; D.reviews.splice(i, 0, r); save(); render(); };
  toast(`‘${r.src}’ 지웠어요`, true);
  // 되돌리기(4초)가 끝나면 사진 파일도 지움. 그 사이 앱을 끄면 사진 파일만 남음 (기록엔 없어 보이지 않음)
  if (r.img) setTimeout(() => { if (!undone) S.deleteImage(r.img); }, 4500);
}

document.addEventListener('click', e => {
  if (pressed) { pressed = false; e.preventDefault(); return; }
  const b = e.target.closest('button,[data-act],[data-menu]'); if (!b) return;
  const d = b.dataset;
  if (d.site) { openSite(d.site, ''); return; }
  if (d.day) { openDay(d.day); return; }
  if (d.del) { swDelete(d.del); return; }
  if (d.mid) { V.memoEdit = +d.mid; drawSheet(); const i = document.querySelector('[data-form=memo] input'); if (i) i.focus(); return; }
  if (d.menu) { if (V.timer) return; V.menu = d.menu; V.reviewOpen = null; V.adding = null; V.rec = false; S.stopListen(); if (d.menu === 'settings') refreshInfo(); render(); return; } // 단어 탭에 들어갈 땐 읽지 않음 (회장님 0.2.1 시험: 들어가자마자 첫 단어가 읽혀 이상함)
  if (d.chk) { const x = todos().find(t => t.id === +d.chk); if (x) { x.done = !x.done; save(); render(); } return; }
  if (d.start) { const x = todos().find(t => t.id === +d.start); if (x) startTimer(x); return; }
  if (d.wt) { V.wordTab = d.wt; render(); return; }
  if (d.grade) { grade(+d.grade); return; }
  if (d.popen) { patOpen(d.popen); return; }
  if (d.pstep) { patStep(d.pstep); return; }
  if (d.psit) { V.pat.sit = d.psit; render(); return; }
  if (d.pex) { const p = PAT && PAT.find(x => x.id === V.pat.id); if (p) S.speak(p.ex[+d.pex][0]); return; }
  if (d.open) { V.reviewOpen = +d.open; render(); return; }
  if (d.subj) { V.addSubj = d.subj; render(); return; }
  if (d.pen) { pad.color = d.pen; document.querySelectorAll('[data-pen]').forEach(x => x.classList.toggle('on', x.dataset.pen === d.pen)); return; }
  if (d.mode) { V.ask.mode = d.mode; render(); return; }
  if (d.ai) { V.ask.ai = d.ai; render(); return; }
  if (d.pick) { const r = D.reviews.find(x => x.id === +d.pick); if (r) { V.ask.from = r.id; V.ask.img = r.img || ''; } closeSheet(); render(); return; }
  if (d.acad) { openSheet('aca', {day: +d.acad}); return; }
  if (d.level) { D.words.level = +d.level; save(); V.queue = null; render(); return; }
  if (d.per) { D.words.perDay = +d.per; save(); V.queue = null; render(); return; }
  act(d.act);
});

function act(a) {
  const A = V.ask;
  switch (a) {
    case 'cal-prev': case 'cal-next': { const c = V.cal; const x = new Date(c.y, c.m + (a === 'cal-next' ? 1 : -1), 1); V.cal = {y: x.getFullYear(), m: x.getMonth()}; render(); break; }
    case 'cal-today': V.cal = null; render(); break;
    case 'memo-cancel': V.memoEdit = null; drawSheet(); break;
    case 'undo': if (undoFn) { undoFn(); undoFn = null; } V.toast = null; drawToast(); break;
    case 'close': V.pending = null; closeSheet(); break;
    case 'confirm-yes': { const f = V.pending; V.pending = null; closeSheet(); if (f) f(); break; }
    case 'exam': openSheet('exam'); break;
    case 'name': openSheet('name'); break;
    case 'name-skip': D.nameAsked = 1; save(); closeSheet(); render(); break;
    case 'exam-clear': D.exam = {name: '', date: ''}; save(); closeSheet(); render(); break;
    case 'aca': openSheet('aca', {day: new Date().getDay()}); break;
    case 'ebs-again': { const t = V.timer && todos().find(x => x.id === V.timer.id); if (t && t.url) openUrl(t.url); break; }
    case 'pause': if (V.timer.paused) { V.timer.pausedMs += Date.now() - V.timer.paused; V.timer.paused = 0; } else V.timer.paused = Date.now(); render(); break;
    case 'finish': finishTimer(); break;
    case 'finish-sheet': closeSheet(); finishTimer(); break;
    case 'score-from-timer': { const t = V.timer && todos().find(x => x.id === V.timer.id); finishTimer(); openSheet('score', {title: t ? t.t : 'EBS', url: t ? t.url : ''}); break; }
    case 'reveal': V.show = true; render(); break;
    case 'listen': { const it = V.queue && V.queue[V.qi]; if (it) S.speak(it.e.w); break; }
    case 'more': { const fresh = deck().filter(x => !D.words.items[x.w]).slice(0, 5); V.queue = fresh.map(e => ({e, isNew: true})); V.qi = 0; V.show = false; if (!fresh.length) toast('이 단어장의 새 단어를 다 했어요'); render(); showWord(); break; }
    case 'pat-listen': { const p = PAT && PAT.find(x => x.id === V.pat.id); if (p) S.speak(p.ex[V.pat.i][0]); break; }
    case 'pat-all': { const p = PAT && PAT.find(x => x.id === V.pat.id); if (p) S.speak(p.ex.map(e => e[0]).join('  ')); break; }
    case 'pat-hint': V.pat.hint = true; render(); break;
    case 'pat-next': patNext(); break;
    case 'pat-list': S.stopListen(); V.rec = false; V.pat.id = null; render(); break;
    case 'rec': startRec(); break;
    case 'add-camera': V.adding = 'photo'; V.addImg = ''; render(); S.photo(true); break;
    case 'add-gallery': V.adding = 'photo'; V.addImg = ''; render(); S.photo(false); break;
    case 'add-pen': padStart('', null); break;
    case 'photo-pen': padStart(V.addImg, null); break;
    case 'r-pen': { const r = D.reviews.find(x => x.id === V.reviewOpen); if (r) padStart(r.img || '', r.id); break; }
    case 'pad-clear': pad.strokes = []; if (pad.redraw) pad.redraw(); break;
    case 'pad-undo': pad.strokes.pop(); if (pad.redraw) pad.redraw(); break;
    case 'pad-save': {
      const r = D.reviews.find(x => x.id === pad.editId);
      if (r && pad.strokes.length) { const name = padSave(); if (name) { if (r.img) S.deleteImage(r.img); r.img = name; save(); toast('저장했어요'); } }
      V.adding = null; V.reviewOpen = pad.editId; padReset(); render(); break;
    }
    case 'add-cancel':
      if (pad.editId) { V.reviewOpen = pad.editId; V.adding = null; padReset(); render(); break; }
      if (V.addImg) S.deleteImage(V.addImg); V.adding = null; V.addImg = ''; padReset(); render(); break;
    case 'r-back': V.reviewOpen = null; render(); break;
    case 'r-ebs': { const r = D.reviews.find(x => x.id === V.reviewOpen); if (r && r.url) openUrl(r.url); break; }
    case 'r-right': {
      markStudy();
      const r = D.reviews.find(x => x.id === V.reviewOpen); if (!r) break;
      r.streak++;
      if (r.streak >= 3) { D.reviews = D.reviews.filter(x => x !== r); D.done.unshift({s: r.s, src: r.src, at: dayNum()}); D.done = D.done.slice(0, 300); if (r.img) S.deleteImage(r.img); toast('세 번 연속 맞혔어요 · 끝낸 문제로'); }
      else { r.due = dayNum() + (r.streak === 1 ? 3 : 7); toast(`잘했어요 · ${r.streak === 1 ? '3일' : '7일'} 뒤 한 번 더`); }
      save(); V.reviewOpen = null; render(); break;
    }
    case 'r-wrong': { markStudy(); const r = D.reviews.find(x => x.id === V.reviewOpen); if (r) { r.streak = 0; r.wrong++; r.due = dayNum() + 1; save(); toast('내일 다시 풀어요'); } V.reviewOpen = null; render(); break; }
    case 'r-ask': { const r = D.reviews.find(x => x.id === V.reviewOpen); V.ask = {img: r ? r.img || '' : '', from: r ? r.id : null, said: '', mode: 'hint', ai: V.ask.ai, sent: false, answer: ''}; V.reviewOpen = null; V.menu = 'ask'; render(); break; }
    case 'ask-pick': openSheet('pick'); break;
    case 'ask-cam': S.photo(true); break;
    case 'ask-clear': A.img = ''; A.from = null; render(); break;
    case 'send': {
      const t = $('#said'); if (t) A.said = t.value.trim();
      if (!A.said) { toast('막힌 곳을 먼저 말하거나 써 주세요'); break; }
      if (!S.sendToAi(A.ai, askPrompt(), A.img || '')) { toast('그 AI 앱을 열지 못했어요'); break; }
      A.sent = true; render(); break;
    }
    case 'paste': { const c = S.clipboard(); if (c) { A.answer = c.slice(0, 4000); render(); } else toast('복사한 답이 없어요. AI 앱에서 답을 길게 눌러 복사해요'); break; }
    case 'save-ans': {
      const ai = AIS.find(x => x.key === A.ai) || {name: 'AI'};
      if (A.from) { const r = D.reviews.find(x => x.id === A.from); if (r) r.answer = A.answer; }
      D.asked.unshift({q: A.said.slice(0, 80), ai: ai.name, at: dayNum()}); D.asked = D.asked.slice(0, 30); save();
      toast(A.from ? '오답에 답을 같이 저장했어요' : '질문 기록에 저장했어요');
      V.ask = {img: '', from: null, said: '', mode: 'hint', ai: A.ai, sent: false, answer: ''}; render(); break;
    }
    case 'ask-new': V.ask = {img: '', from: null, said: '', mode: 'hint', ai: A.ai, sent: false, answer: ''}; render(); break;
    case 'wifi': S.openWifi(); break;
    case 'bright-auto': S.setBrightness(-1); render(); break;
    case 'pin': V.pending = null; openSheet('pin', {title: INFO.hasPin ? '보호자 비밀번호 바꾸기' : '보호자 비밀번호 정하기', mode: 'set', hasOld: INFO.hasPin}); break;
    case 'lock': askPin(INFO.lock ? '잠금 끄기' : '잠금 켜기', INFO.lock ? '끄면 다른 앱을 쓸 수 있어요. 다 쓰면 다시 켜 주세요.' : '', p => { if (S.setLock(!INFO.lock, p)) { refreshInfo(); render(); } else toast('비밀번호가 달라요'); }); break;
    case 'release': askPin('관리 끝내기', '보통 태블릿으로 돌아가요. 공부 전용 잠금을 다시 켜려면 공장 초기화 뒤 QR로 다시 설치해야 해요.', p => { if (S.release(p)) toast('보통 태블릿으로 돌아갔어요'); else toast('비밀번호가 달라요'); }); break;
    case 'update': toast('확인하고 있어요…'); S.checkUpdate(); break;
    case 'about': fetch('data/about.txt').then(r => r.text()).then(t => openSheet('about', {text: t})).catch(() => toast('출처 파일을 열지 못했어요')); break;
  }
}
window.steadyUpdate = m => { toast(m); refreshInfo(); if (V.menu === 'settings') render(); };

document.addEventListener('input', e => {
  const r = e.target.dataset && e.target.dataset.range;
  if (r === 'bright') S.setBrightness(+e.target.value / 100);
  else if (r === 'vol') S.setVolume(+e.target.value / 100);
  else if (e.target.id === 'said') V.ask.said = e.target.value;
});

document.addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target, k = f.dataset.form;
  if (f.id === 'addf') { const v = $('#addi').value.trim(); if (!v) return; addTodo(v); render(); const i = $('#addi'); if (i) i.focus(); return; }
  if (f.id === 'addr') {
    const src = $('#src').value.trim() || (V.adding === 'pen' ? '손으로 옮겨 쓴 문제' : '사진으로 넣은 문제');
    let name = V.addImg;
    if (V.adding === 'pen') {
      if (!pad.strokes.length && !pad.bg) { toast('문제를 먼저 써 주세요'); return; }
      if (pad.strokes.length) { name = padSave(); if (name && pad.bg) S.deleteImage(pad.bg); } else name = pad.bg;
    }
    if (!name) { toast(V.adding === 'pen' ? '그림을 저장하지 못했어요' : '사진을 먼저 넣어 주세요'); return; }
    D.reviews.push({id: Date.now(), s: V.addSubj, src: src.slice(0, 60), img: name || '', due: dayNum() + 1, streak: 0, wrong: 1, answer: '', url: ''});
    save(); V.adding = null; V.addImg = ''; padReset(); toast('오답에 넣었어요 · 내일 다시 풀어요'); render(); return;
  }
  const v = n => (f.elements[n] ? f.elements[n].value.trim() : '');
  if (k === 'exam') { D.exam = {name: v('name'), date: v('date')}; save(); closeSheet(); render(); }
  else if (k === 'memo') {
    const t = v('v').slice(0, 80), key = V.sheet.data.key;
    if (!t) { toast('메모를 먼저 써 주세요'); return; }
    const list = D.memos[key] || (D.memos[key] = []), ed = list.filter(x => x.id === V.memoEdit)[0];
    if (ed) ed.t = t; else list.push({id: Date.now(), t});
    V.memoEdit = null; save(); render(); drawSheet();
    toast(ed ? '메모를 고쳤어요' : '메모를 넣었어요');
  }
  else if (k === 'name') { D.name = v('v').slice(0, 10); D.nameAsked = 1; save(); closeSheet(); render(); }
  else if (k === 'aca') { D.aca[V.sheet.data.day] = v('v'); save(); closeSheet(); render(); }
  else if (k === 'score') {
    const wr = v('wr').split(/[^0-9]+/).filter(Boolean), d = V.sheet.data;
    wr.forEach((n, i) => D.reviews.push({id: Date.now() + i, s: d.url ? siteOf(d.url).name : 'EBS', src: `${(d.title || '시험지').slice(0, 40)} ${n}번`, img: '', due: dayNum() + 1, streak: 0, wrong: 1, answer: '', url: d.url || ''}));
    save(); closeSheet(); toast(`${v('sc') ? v('sc') + ' · ' : ''}틀린 ${wr.length}문제를 오답에 넣었어요`); render();
  } else if (k === 'pin') {
    const d = V.sheet.data;
    if (d.mode === 'set') {
      if (!/^[0-9]{4,}$/.test(v('p'))) { toast('숫자 4자리 이상으로 정해 주세요'); return; }
      if (!S.setPin(v('old'), v('p'))) { toast('지금 비밀번호가 달라요'); return; }
      closeSheet(); refreshInfo(); toast('보호자 비밀번호를 정했어요'); render();
    } else { const ok = V.pending; V.pending = null; closeSheet(); if (ok) ok(v('p')); }
  }
});

// ---------- 키보드 케이스 단축키 ----------
document.addEventListener('keydown', e => {
  const typing = /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '');
  if (e.key === 'Escape') { window.steadyBack(); return; }
  if (typing || V.sheet) return;
  if (V.menu === 'words' && V.wordTab === 'card' && V.queue && V.qi < V.queue.length) {
    if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); if (!V.show) act('reveal'); else grade(2); }
    else if (V.show && ['1', '2', '3'].includes(e.key)) grade(+e.key - 1);
  } else if (V.menu === 'words' && V.wordTab === 'pat' && V.pat.id !== null && (V.pat.view === 'say' || V.pat.view === 'drill')) {
    if (e.key === ' ') { e.preventDefault(); startRec(); }
    else if (e.key === 'Enter') { e.preventDefault(); patNext(); }
  }
});

// ---------- 안드로이드가 부르는 것 ----------
window.steadyBack = () => {
  if (V.sheet) { if (V.sheet.data && V.sheet.data.must) return true; closeSheet(); return true; }
  if (V.timer) { openSheet('confirm', {title: '타이머를 끝낼까요?', msg: '지금까지 한 시간을 기록하고 할 일을 체크해요.', yes: '끝내기'}); V.pending = finishTimer; return true; }
  if (V.adding) { act('add-cancel'); return true; }
  if (V.reviewOpen !== null) { V.reviewOpen = null; render(); return true; }
  if (V.menu === 'words' && V.wordTab === 'pat' && V.pat.id !== null) { act('pat-list'); return true; }
  if (V.menu === 'ask' && V.ask.sent) { act('ask-new'); return true; }
  if (V.menu !== 'home') { V.menu = 'home'; render(); return true; }
  return false;
};
window.steadyResume = evs => {
  let list = [];
  try { list = JSON.parse(evs || '[]'); } catch (e) { list = []; }
  list.forEach(ev => {
    if (ev.type === 'add') { const nm = ev.name || siteOf(ev.url).name; addTodo(ev.title || nm, nm, ev.url); toast(`오늘 계획에 넣었어요 · ${nm}`); }
    else if (ev.type === 'score') {
      if (V.timer) { const t = todos().find(x => x.id === V.timer.id); finishTimer(); openSheet('score', {title: t ? t.t : ev.title, url: ev.url}); }
      else openSheet('score', {title: ev.title, url: ev.url});
    }
  });
  if (!list.some(ev => ev.type === 'score') && V.timer) { const t = todos().find(x => x.id === V.timer.id); if (t && t.url && !V.sheet) openSheet('back-from-ebs', {title: t.t, site: siteOf(t.url).name}); }
  refreshInfo();
  if (!V.sheet && INFO.owner && !INFO.hasPin) openSheet('pin', {title: '보호자 비밀번호 정하기', msg: '잠금을 풀거나 설정을 바꿀 때 써요. 꼭 기억해 주세요.', mode: 'set', hasOld: false, must: true});
  else if (!V.sheet && !D.name && !D.nameAsked) openSheet('name');
  render();
};
window.steadyEvent = s => {
  let ev = {}; try { ev = JSON.parse(s); } catch (e) { return; }
  if (ev.type === 'web-updated') { if (V.timer) V.reloadLater = true; else { toast('화면이 새로 바뀌었어요'); setTimeout(() => location.reload(), 1200); } }
};

// ---------- 시작 ----------
refreshInfo();
loadData();
render();
window.steadyResume(S.takeEvents());
